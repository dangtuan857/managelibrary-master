#ifndef _BOOK_CPP
#define _BOOK_CPP

#include <iostream>
#include <string>

using namespace std;

struct book
{
	string code;
	string bookname;
	string category;
	string amount;
	int sl;
	//	string price;
};

struct book2
{
	string code;
	string bookname;
	int sl;
	string category;
};

#endif